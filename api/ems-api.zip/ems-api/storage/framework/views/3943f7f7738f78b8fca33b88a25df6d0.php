<!DOCTYPE html>
<html>
<head>
    <title>Log In</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo e(asset('icons/atte1.jpg')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login.css')); ?>">
    <script src="<?php echo e(asset('js/jquery-2.2.3.min.js')); ?>"></script>

    <script>
      $(window).on("load resize ", function () {
          var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
          $('.tbl-header').css({ 'padding-right': scrollWidth });
      }).resize();

      $(document).ready(function () {
          $(document).on('click', '.message', function () {
              $('form').animate({ height: "toggle", opacity: "toggle" }, "slow");
              $('h1').animate({ height: "toggle", opacity: "toggle" }, "slow");
          });
      });
    </script>
</head>
<body>


<main>
    <h1 class="slideInDown animated">Please, Login with the Admin E-mail and Password</h1>
    <h1 class="slideInDown animated" id="reset">Please, Enter your Email to send the reset password link</h1>

    <section>
        <div class="slideInDown animated">
            <div class="login-page">
                <div class="form">
                    
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul style="margin: 0; padding: 0; list-style: none;">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    <form class="reset-form" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="email" name="email" placeholder="E-mail..." required/>
                        <button type="submit">Reset</button>
                        <p class="message"><a href="#">LogIn</a></p>
                    </form>

                    
                    <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="email" name="email" placeholder="E-mail..." value="<?php echo e(old('email')); ?>" required/>
                        <input type="password" name="password" placeholder="Password" required/>
                        <button type="submit">Login</button>
                        <p class="message">Forgot your Password? <a href="#">Reset your password</a></p>
                    </form>

                </div>
            </div>
        </div>
    </section>
</main>
</body>
</html>
<?php /**PATH C:\wamp64\www\ems\ems-api\resources\views/login.blade.php ENDPATH**/ ?>