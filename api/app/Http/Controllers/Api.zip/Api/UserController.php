<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function listUsersByAccessAndDepartmentOrDevice(Request $request)
    {
        $authUser = Auth::user();

        if (!$authUser) {
            return response()->json(['message' => 'Unauthorized.'], 403);
        }

        $departmentId = $request->input('department_id');
        $deviceDep    = $request->input('device_dep');

        $query = DB::table('users')
            ->leftJoin('department', 'users.department_id', '=', 'department.id')
            ->leftJoin('devices', 'users.device_uid', '=', 'devices.device_uid')
            ->leftJoin('company as department_company', 'department.company_id', '=', 'department_company.id')
            ->leftJoin('company as device_company', 'devices.company_id', '=', 'device_company.id')
            ->select([
                'users.id',
                'users.username',
                'users.serialnumber',
                'users.gender',
                'users.fingerprint_id',
                'users.user_date as date',
                'users.device_uid',
                'users.device_dep',
                'users.department_id',
                'users.company_id',
                'users.branch_id',
                'department.department_name',
                'devices.device_name',
                'users.email',
                DB::raw('COALESCE(department_company.name, device_company.name) as company_name'),
            ])
            ->where('users.del_fingerid', 0)
            ->where(function ($query) {
                $query->whereNull('user_types_id')
                    ->orWhereNotIn('user_types_id', [1, 2, 3, 4]);
            })
            ->orderBy('users.id', 'desc');

        // ── Request-level filters ──────────────────────────────────────────
        if ($departmentId) {
            $query->where('users.department_id', $departmentId);
        } elseif ($deviceDep) {
            $query->where(function ($q) use ($deviceDep) {
                $q->whereNull('users.department_id')
                    ->orWhere('users.department_id', 0);
            })->where('users.device_dep', $deviceDep);
        }

        // ── Role-based filtering ───────────────────────────────────────────
        if ($authUser->user_types_id == 1) {
            // Super Admin — sees everything

        } elseif ($authUser->user_types_id == 2) {
            // Company Admin — sees employees belonging to their companies
            $companyIds = DB::table('company_users')
                ->where('users_id', $authUser->id)
                ->pluck('company_id');

            if ($companyIds->isEmpty()) {
                return response()->json([
                    'data'    => [],
                    'message' => 'No companies assigned to this user.'
                ]);
            }

            $query->where(function ($q) use ($companyIds) {
                $q->whereIn('department.company_id', $companyIds)
                    ->orWhereIn('devices.company_id', $companyIds);
            });

        } elseif ($authUser->user_types_id == 3) {
            // Branch Admin — sees employees belonging to their branches
            $branchIds = DB::table('branch_user')
                ->where('users_id', $authUser->id)
                ->pluck('branch_id');

            if ($branchIds->isEmpty()) {
                return response()->json(['data' => []]);
            }

            $query->where(function ($q) use ($branchIds) {
                $q->whereIn('department.branch_id', $branchIds)
                    ->orWhereIn('devices.branch_id', $branchIds);
            });

        } elseif ($authUser->user_types_id == 4) {
            // Dept Admin — show all employees of the same company as this user.
            // Resolution order:
            //   1. users.company_id (direct)
            //   2. department.company_id (via their department)
            //   3. devices.company_id   (via their device_uid)

            $companyId = null;

            // 1. Direct company_id on the user row
            if (!empty($authUser->company_id)) {
                $companyId = $authUser->company_id;
            }

            // 2. Via department_users → department → company_id
            if (!$companyId) {
                $companyId = DB::table('department_users')
                    ->join('department', 'department_users.department_id', '=', 'department.id')
                    ->where('department_users.users_id', $authUser->id)
                    ->value('department.company_id');
            }

            // 3. Via device_uid → devices → company_id
            if (!$companyId && !empty($authUser->device_uid)) {
                $companyId = DB::table('devices')
                    ->where('device_uid', $authUser->device_uid)
                    ->value('company_id');
            }

            if (!$companyId) {
                return response()->json([
                    'data'    => [],
                    'message' => 'Could not determine company for this user.'
                ]);
            }

            // Show all employees whose department or device belongs to this company
            $query->where(function ($q) use ($companyId) {
                $q->where('department.company_id', $companyId)
                    ->orWhere('devices.company_id', $companyId);
            });

        } else {
            return response()->json(['message' => 'Invalid user role.'], 403);
        }

        $users = $query->get()->map(function ($user) {
            $user->fingerprint_status = $user->fingerprint_id ? 'Added' : 'Not Added';
            return $user;
        });

        return response()->json(['data' => $users]);
    }

    public function companyAdmins()
    {
        $authUser = Auth::user();
        if (!$authUser || $authUser->user_types_id != 1) {
            return response()->json([
                'message' => 'Unauthorized. Only Super Admin can view company admins.'
            ], 403);
        }

        $companyAdmins = DB::table('users')
            ->select([
                'id', 'username', 'email', 'serialnumber',
                'fingerprint_id', 'device_uid', 'device_dep', 'user_types_id',
            ])
            ->where('user_types_id', 2)
            ->get();

        return response()->json(['data' => $companyAdmins]);
    }

    public function branchAdmins()
    {
        $authUser = Auth::user();
        if (!$authUser || !in_array($authUser->user_types_id, [1, 2])) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $branchAdmins = DB::table('users')
            ->select(['id', 'username', 'email', 'user_types_id'])
            ->where('user_types_id', 3)
            ->get();

        return response()->json(['data' => $branchAdmins]);
    }
}