<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use App\Models\User;
use App\Models\Device;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class ManageUserController extends Controller
{
    // ────────────────────────────────────────────────────────────────────────
    // HELPER: resolve company_id for a type-4 (Dept Admin) user
    // Resolution order:
    //   1. users.company_id  (direct column)
    //   2. department_users → department → company_id
    //   3. users.device_uid  → devices   → company_id
    // ────────────────────────────────────────────────────────────────────────
    private function resolveCompanyIdForDeptAdmin($authUser): ?int
    {
        // 1. Direct company_id on the user row
        if (!empty($authUser->company_id)) {
            return (int) $authUser->company_id;
        }

        // 2. Via department_users → department → company_id
        $companyId = DB::table('department_users')
            ->join('department', 'department_users.department_id', '=', 'department.id')
            ->where('department_users.users_id', $authUser->id)
            ->value('department.company_id');

        if ($companyId) {
            return (int) $companyId;
        }

        // 3. Via device_uid → devices → company_id
        if (!empty($authUser->device_uid)) {
            $companyId = DB::table('devices')
                ->where('device_uid', $authUser->device_uid)
                ->value('company_id');

            if ($companyId) {
                return (int) $companyId;
            }
        }

        return null;
    }


    // ────────────────────────────────────────────────────────────────────────
    // INDEX — list employees
    // ────────────────────────────────────────────────────────────────────────
    public function index(Request $request)
    {
        $authUser = Auth::user();
        if (!$authUser) {
            return response()->json(['message' => 'Unauthorized.'], 403);
        }

        $query = DB::table('users')
            ->leftJoin('department', 'users.department_id', '=', 'department.id')
            ->leftJoin('devices', 'users.device_uid', '=', 'devices.device_uid')
            ->leftJoin('company as dept_company', 'department.company_id', '=', 'dept_company.id')
            ->leftJoin('company as dev_company', 'devices.company_id', '=', 'dev_company.id')
            ->select([
                'users.id',
                'users.username',
                'users.serialnumber',
                'users.gender',
                'users.fingerprint_id',
                'users.user_date',
                'users.device_uid',
                'users.device_dep',
                'users.department_id',
                'department.department_name',
                'devices.device_name',
                'users.email',
                DB::raw('COALESCE(dept_company.name, dev_company.name) as company_name'),
            ])
            ->where('users.del_fingerid', 0)
            ->where(function ($q) {
                $q->whereNull('users.user_types_id')
                  ->orWhereNotIn('users.user_types_id', [1, 2, 3, 4]);
            })
            ->orderBy('users.id', 'desc');

        // ── Role-based filtering ───────────────────────────────────────────
        if ($authUser->user_types_id == 1) {
            // Super Admin — sees everything

        } elseif ($authUser->user_types_id == 2) {
            // Company Admin
            $companyIds = DB::table('company_users')
                ->where('users_id', $authUser->id)
                ->pluck('company_id');

            $query->where(function ($q) use ($companyIds) {
                $q->whereIn('department.company_id', $companyIds)
                  ->orWhereIn('devices.company_id', $companyIds);
            });

        } elseif ($authUser->user_types_id == 3) {
            // Branch Admin
            $branchIds = DB::table('branch_user')
                ->where('users_id', $authUser->id)
                ->pluck('branch_id');

            $query->where(function ($q) use ($branchIds) {
                $q->whereIn('department.branch_id', $branchIds)
                  ->orWhereIn('devices.branch_id', $branchIds);
            });

        } elseif ($authUser->user_types_id == 4) {
    $companyId = $this->resolveCompanyIdForDeptAdmin($authUser);

    if (!$companyId) {
        return response()->json([
            'data'  => [],
            'users' => [],
            'message' => 'Could not determine company for this user.'
        ]);
    }

    // FIX: department.company_id only — device is shared, don't filter by it
    $query->where('department.company_id', $companyId);
}

        $users = $query->get();
        return response()->json(['data' => $users, 'users' => $users]);
    }


    // ────────────────────────────────────────────────────────────────────────
    // STORE — add new employee
    // ────────────────────────────────────────────────────────────────────────
    public function store(Request $request)
    {
        $authUser = Auth::user();
        if (!$authUser) {
            return response()->json(['message' => 'Unauthorized.'], 403);
        }

        // Base validation
        $rules = [
            'username'        => 'required|string',
            'gender'          => 'required|in:Male,Female',
            'department_name' => 'required|string|exists:department,department_name',
            'user_types_id'   => 'required|integer|exists:user_types,id',
        ];

        $userTypeId = (int) $request->input('user_types_id');
        if ($userTypeId !== 5) {
            $rules['email']    = 'required|email|unique:users,email';
            $rules['password'] = 'required|string|min:8';
        }

        $request->validate($rules);

        $department = DB::table('department')
            ->where('department_name', $request->department_name)
            ->first();

        if (!$department) {
            return response()->json(['message' => 'Department not found'], 422);
        }

        // Role-based access check
        switch ($authUser->user_types_id) {
            case 1:
                break;

            case 2:
                $companyIds = DB::table('company_users')
                    ->where('users_id', $authUser->id)
                    ->pluck('company_id')->toArray();
                if (!in_array($department->company_id, $companyIds)) {
                    return response()->json(['message' => 'You do not have permission to add user to this department'], 403);
                }
                break;

            case 3:
                $branchIds = DB::table('branch_user')
                    ->where('users_id', $authUser->id)
                    ->pluck('branch_id')->toArray();
                if (!in_array($department->branch_id, $branchIds)) {
                    return response()->json(['message' => 'You do not have permission to add user to this department'], 403);
                }
                break;

            case 4:
                // Dept Admin — allow adding to any dept under their company
                $companyId = $this->resolveCompanyIdForDeptAdmin($authUser);
                if (!$companyId || (int) $department->company_id !== $companyId) {
                    return response()->json(['message' => 'You do not have permission to add user to this department'], 403);
                }
                break;

            default:
                return response()->json(['message' => 'Invalid user role'], 403);
        }

        // Build user data
        $userData = [
            'username'       => $request->username,
            'fingerprint_id' => $request->serialnumber,
            'gender'         => $request->gender,
            'user_date'      => now(),
            'department_id'  => $department->id,
            'device_uid'     => $department->device_uid,
            'add_fingerid'   => 2,
            'user_types_id'  => $userTypeId,
            'company_id'     => $department->company_id,
            'branch_id'      => $department->branch_id,
        ];

        if ($userTypeId !== 5) {
            $userData['email']    = $request->email;
            $userData['password'] = \Illuminate\Support\Facades\Hash::make($request->password);
        }

        $user = User::create($userData);

        DB::table('department_users')->insert([
            'users_id'      => $user->id,
            'department_id' => $department->id,
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);

        return response()->json([
            'message' => 'User added successfully',
            'user'    => $user,
        ], 201);
    }


    // ────────────────────────────────────────────────────────────────────────
    // UPDATE — edit employee
    // ────────────────────────────────────────────────────────────────────────
    public function update(Request $request, $id)
    {
        $authUser = Auth::user();
        if (!$authUser) {
            return response()->json(['message' => 'Unauthorized.'], 403);
        }

        $user = User::findOrFail($id);
        $data = $request->all();

        if (isset($data['department_name'])) {
            $request->validate([
                'department_name' => 'string|exists:department,department_name',
            ]);

            $department = DB::table('department')
                ->where('department_name', $data['department_name'])
                ->first();

            if (!$department) {
                return response()->json(['message' => 'Department not found'], 422);
            }

            switch ($authUser->user_types_id) {
                case 1:
                    break;

                case 2:
                    $companyIds = DB::table('company_users')
                        ->where('users_id', $authUser->id)
                        ->pluck('company_id')->toArray();
                    if (!in_array($department->company_id, $companyIds)) {
                        return response()->json(['message' => 'You do not have permission to assign user to this department'], 403);
                    }
                    break;

                case 3:
                    $branchIds = DB::table('branch_user')
                        ->where('users_id', $authUser->id)
                        ->pluck('branch_id')->toArray();
                    if (!in_array($department->branch_id, $branchIds)) {
                        return response()->json(['message' => 'You do not have permission to assign user to this department'], 403);
                    }
                    break;

                case 4:
                    // Dept Admin — allow reassigning to any dept under their company
                    $companyId = $this->resolveCompanyIdForDeptAdmin($authUser);
                    if (!$companyId || (int) $department->company_id !== $companyId) {
                        return response()->json(['message' => 'You do not have permission to assign user to this department'], 403);
                    }
                    break;

                default:
                    return response()->json(['message' => 'Invalid user role'], 403);
            }

            $data['department_id'] = $department->id;

            DB::table('department_users')
                ->where('users_id', $user->id)
                ->update(['department_id' => $department->id]);
        }

        if (!isset($data['user_date'])) {
            $data['user_date'] = now();
        }

        $user->update($data);

        return response()->json(['message' => 'User updated', 'user' => $user]);
    }


    // ────────────────────────────────────────────────────────────────────────
    // DESTROY — soft delete
    // ────────────────────────────────────────────────────────────────────────
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->del_fingerid = 1;
        $user->save();

        return response()->json(['message' => 'User removed']);
    }


    public function availableFingerprintIds(Request $request)
    {
        $request->validate([
            'device_uid' => 'required|string'
        ]);

        $usedIds = User::where('device_uid', $request->device_uid)
            ->pluck('fingerprint_id')
            ->toArray();

        $allIds       = range(1, 127);
        $availableIds = array_values(array_diff($allIds, array_map('intval', $usedIds)));

        return response()->json([
            'device_uid'                => $request->device_uid,
            'available_fingerprint_ids' => $availableIds
        ]);
    }


    public function selectUserForFingerprint(Request $request)
    {
        $request->validate([
            'serialnumber' => 'required|numeric',
            'device_uid'   => 'required|string',
        ]);

        $user = User::where('serialnumber', $request->serialnumber)
            ->where('device_uid', $request->device_uid)
            ->first();

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        User::where('device_uid', $user->device_uid)
            ->update([
                'fingerprint_select' => 0,
                'add_fingerid'       => 0,
            ]);

        $user->update([
            'fingerprint_select' => 1,
            'add_fingerid'       => 1,
        ]);

        return response()->json([
            'message' => 'User selected for fingerprint enrollment',
            'user'    => $user
        ]);
    }


    public function addFingerprintId(Request $request)
    {
        $request->validate([
            'fingerprint_id' => 'required|integer|min:1|max:127',
            'device_uid'     => 'required|string',
            'serialnumber'   => 'required|numeric',
        ]);

        $alreadyUsed = User::where('fingerprint_id', $request->fingerprint_id)
            ->where('device_uid', $request->device_uid)
            ->exists();

        if ($alreadyUsed) {
            return response()->json(['message' => 'Fingerprint ID already in use'], 409);
        }

        $user = User::where('serialnumber', $request->serialnumber)
            ->where('device_uid', $request->device_uid)
            ->where('fingerprint_select', 1)
            ->where('add_fingerid', 1)
            ->first();

        if (!$user) {
            return response()->json(['message' => 'No valid user found for assigning fingerprint'], 404);
        }

        $user->update(['fingerprint_id' => $request->fingerprint_id]);

        return response()->json([
            'message' => 'Fingerprint ID assigned. Now scan fingerprint on device.',
            'user'    => $user
        ]);
    }


    public function checkScanStatus(Request $request)
    {
        $request->validate([
            'serialnumber' => 'required|numeric',
            'device_uid'   => 'required|string',
        ]);

        $user = User::where('serialnumber', $request->serialnumber)
            ->where('device_uid', $request->device_uid)
            ->first();

        if (!$user) {
            return response()->json(['status' => 'user_not_found', 'message' => 'User not found'], 404);
        }

        if ($user->add_fingerid == 0) {
            return response()->json([
                'status'         => 'completed',
                'message'        => 'Fingerprint scan completed and saved',
                'fingerprint_id' => $user->fingerprint_id,
                'serialnumber'   => $user->serialnumber,
                'username'       => $user->username,
                'id'             => $user->id
            ]);
        }

        if ($user->add_fingerid == 1) {
            if ($user->fingerprint_id) {
                return response()->json([
                    'status'         => 'scanning',
                    'message'        => 'Fingerprint ID assigned but scan not completed yet',
                    'fingerprint_id' => $user->fingerprint_id
                ], 202);
            } else {
                return response()->json([
                    'status'  => 'id_pending',
                    'message' => 'User selected but fingerprint ID not assigned yet'
                ], 202);
            }
        }

        return response()->json([
            'status'  => 'not_selected',
            'message' => 'Fingerprint enrollment not started for this user'
        ], 200);
    }


    public function assignUserToFingerprint(Request $request)
    {
        $request->validate([
            'serialnumber'   => 'required|numeric',
            'device_uid'     => 'required|string',
            'fingerprint_id' => 'required|integer|min:1|max:127',
        ]);

        $user = User::where('serialnumber', $request->serialnumber)
            ->where('device_uid', $request->device_uid)
            ->first();

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        User::where('device_uid', $request->device_uid)
            ->update([
                'fingerprint_select' => 0,
                'add_fingerid'       => 0,
            ]);

        $user->update([
            'fingerprint_select' => 1,
            'add_fingerid'       => 1,
            'fingerprint_id'     => $request->fingerprint_id
        ]);

        return response()->json([
            'message' => 'User selected and fingerprint ID assigned. Please scan fingerprint on device.',
            'user'    => $user
        ]);
    }


    public function deselectUserForFingerprint(Request $request)
    {
        $request->validate([
            'device_uid' => 'required|string',
        ]);

        User::where('device_uid', $request->device_uid)
            ->update(['fingerprint_select' => 0]);

        return response()->json(['message' => 'Fingerprint deselected']);
    }


    public function cancelEnrollment(Request $request)
    {
        $request->validate([
            'serialnumber' => 'required|numeric',
            'device_uid'   => 'required|string',
        ]);

        $user = User::where('serialnumber', $request->serialnumber)
            ->where('device_uid', $request->device_uid)
            ->first();

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $user->update([
            'fingerprint_select' => 0,
            'add_fingerid'       => 2,
            'fingerprint_id'     => null
        ]);

        return response()->json([
            'message' => 'Fingerprint enrollment cancelled',
            'user'    => $user
        ]);
    }
}