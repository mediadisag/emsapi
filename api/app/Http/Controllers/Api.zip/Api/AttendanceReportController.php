<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AttendanceReportController extends Controller
{
    public function attendanceStatus(Request $request)
    {
        try {
            $type = $request->input('type', 'monthly'); // default monthly

            // Validate input based on type
            switch ($type) {
                case 'weekly':
                    $request->validate([
                        'week_start' => 'required|date',
                        'department_name' => 'nullable|string',
                    ]);
                    $startDate = Carbon::parse($request->week_start)->startOfDay();
                    $endDate = $startDate->copy()->addDays(6)->endOfDay();
                    break;

                case 'custom':
                    $request->validate([
                        'start_date' => 'required|date',
                        'end_date' => 'required|date|after_or_equal:start_date',
                        'department_name' => 'nullable|string',
                    ]);
                    $startDate = Carbon::parse($request->start_date)->startOfDay();
                    $endDate = Carbon::parse($request->end_date)->endOfDay();
                    break;

                case 'yearly':
                    $request->validate([
                        'year' => 'required|integer|min:2000',
                        'department_name' => 'nullable|string',
                    ]);
                    $startDate = Carbon::create($request->year, 1, 1)->startOfDay();
                    $endDate = Carbon::create($request->year, 12, 31)->endOfDay();
                    break;

                case 'monthly':
                default:
                    $request->validate([
                        'month' => 'required|integer|min:1|max:12',
                        'year' => 'required|integer|min:2000',
                        'department_name' => 'nullable|string',
                    ]);
                    $startDate = Carbon::create($request->year, $request->month, 1)->startOfDay();
                    $endDate = $startDate->copy()->endOfMonth()->endOfDay();
                    break;
            }

            $authUser = Auth::user();

            // Base query for users with department join
            $usersQuery = DB::table('users')
                ->select('users.id', 'users.username', 'users.department_id', 'department.department_name as department_name')
                ->leftJoin('department', 'users.department_id', '=', 'department.id')
                ->whereNotNull('users.fingerprint_id') // only users with fingerprint_id
                ->where('users.fingerprint_id', '!=', 0)
                ->orderBy('users.username', 'asc');

            // Filter by department_name if provided
            if ($request->filled('department_name')) {
                $usersQuery->where('department.department_name', $request->department_name);
            } else {
                // Role-based filtering
                if ($authUser->user_types_id == 2) {
                    // Company Admin: departments under user's companies
                    $companyIds = DB::table('company_users')
                        ->where('users_id', $authUser->id)
                        ->pluck('company_id');

                    if ($companyIds->isEmpty()) {
                        return response()->json(['status' => 'success', 'data' => []]);
                    }

                    $accessibleDeps = DB::table('department')
                        ->whereIn('company_id', $companyIds)
                        ->pluck('id');

                    if ($accessibleDeps->isEmpty()) {
                        return response()->json(['status' => 'success', 'data' => []]);
                    }

                    $usersQuery->whereIn('users.department_id', $accessibleDeps);

                } elseif (in_array($authUser->user_types_id, [3, 4])) {
                    // Branch Admin or Department Admin: departments assigned to the user
                    $accessibleDeps = DB::table('department_users')
                        ->where('users_id', $authUser->id)
                        ->pluck('department_id');

                    if ($accessibleDeps->isEmpty()) {
                        return response()->json(['status' => 'success', 'data' => []]);
                    }

                    $usersQuery->whereIn('users.department_id', $accessibleDeps);
                }
                // Super Admin (user_types_id == 1) sees all users (no filter)
            }

            $users = $usersQuery->get();

            if ($users->isEmpty()) {
                return response()->json(['status' => 'success', 'data' => []]);
            }

            // Get logs for these users in date range
            $logs = DB::table('users_logs')
                ->whereBetween('checkindate', [$startDate->toDateString(), $endDate->toDateString()])
                ->whereIn('username', $users->pluck('username'))
                ->get()
                ->groupBy('username');

            $report = [];

            for ($date = $startDate->copy(); $date->lte($endDate); $date->addDay()) {
                $dateStr = $date->toDateString();
                $dayName = $date->format('l'); // Get the day name (e.g., Monday, Tuesday)
                foreach ($users as $user) {
                    $logForDay = isset($logs[$user->username])
                        ? $logs[$user->username]->firstWhere('checkindate', $dateStr)
                        : null;

                    if ($logForDay) {
                        $timeIn = $logForDay->timein;
                        $timeOut = $logForDay->timeout;

                        if ($timeIn && $timeOut) {
                             $startTimestamp = strtotime($timeIn);
                            $endTimestamp = strtotime($timeOut);
                            $diffInSeconds = $endTimestamp - $startTimestamp;

                            if ($diffInSeconds < 0) {
                            // Handle case where timeout is before timein (maybe overnight shift)
                                $workingHours = "00:00:00";
                            } else {
                                $hours = floor($diffInSeconds / 3600);
                                $minutes = floor(($diffInSeconds % 3600) / 60);
                                $seconds = $diffInSeconds % 60;
                                $workingHours = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
                            }
                        } else {
                            $workingHours = "Incomplete";
                        }
                        $status = 'Present';
                    } else {
                        $timeIn = null;
                        $timeOut = null;
                        $workingHours = "00:00:00";
                        $status = 'Absent';
                    }

                    $report[] = [
                        'name' => $user->username,
                        'department' => $user->department_name,
                        'date' => $dateStr,
                        'day' => $dayName,
                        'status' => $status,
                        'time_in' => $timeIn ? date('H:i:s', strtotime($timeIn)) : null,
                        'time_out' => $timeOut ? date('H:i:s', strtotime($timeOut)) : null,
                        'working_hours' => $workingHours,
                    ];
                }
            }

            return response()->json([
                'status' => 'success',
                'data' => $report,
                'period' => [
                    'type' => $type,
                    'start_date' => $startDate->toDateString(),
                    'end_date' => $endDate->toDateString(),
                ],
            ]);
        } catch (\Exception $e) {
            \Log::error('AttendanceReportController attendanceStatus error: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => 'Something went wrong: ' . $e->getMessage(),
            ], 500);
        }
        
    }
    public function exportAttendance(Request $request)
{
    try {
        $type = $request->input('type', 'monthly'); // default monthly

        // Validate input based on type
        switch ($type) {
            case 'weekly':
                $request->validate([
                    'week_start' => 'required|date',
                    'department_name' => 'nullable|string',
                ]);
                $startDate = Carbon::parse($request->week_start)->startOfDay();
                $endDate = $startDate->copy()->addDays(6)->endOfDay();
                break;

            case 'custom':
                $request->validate([
                    'start_date' => 'required|date',
                    'end_date' => 'required|date|after_or_equal:start_date',
                    'department_name' => 'nullable|string',
                ]);
                $startDate = Carbon::parse($request->start_date)->startOfDay();
                $endDate = Carbon::parse($request->end_date)->endOfDay();
                break;

            case 'yearly':
                $request->validate([
                    'year' => 'required|integer|min:2000',
                    'department_name' => 'nullable|string',
                ]);
                $startDate = Carbon::create($request->year, 1, 1)->startOfDay();
                $endDate = Carbon::create($request->year, 12, 31)->endOfDay();
                break;

            case 'monthly':
            default:
                $request->validate([
                    'month' => 'required|integer|min:1|max:12',
                    'year' => 'required|integer|min:2000',
                    'department_name' => 'nullable|string',
                ]);
                $startDate = Carbon::create($request->year, $request->month, 1)->startOfDay();
                $endDate = $startDate->copy()->endOfMonth()->endOfDay();
                break;
        }

        $authUser = Auth::user();

        // Base query for users with department join
        $usersQuery = DB::table('users')
            ->select('users.id', 'users.username', 'users.department_id', 'department.department_name as department_name')
            ->leftJoin('department', 'users.department_id', '=', 'department.id')
            ->whereNotNull('users.fingerprint_id') // only users with fingerprint_id
            ->where('users.fingerprint_id', '!=', 0);

        // Filter by department_name if provided
        if ($request->filled('department_name')) {
            $usersQuery->where('department.department_name', $request->department_name);
        } else {
            // Role-based filtering
            if ($authUser->user_types_id == 2) {
                // Company Admin: departments under user's companies
                $companyIds = DB::table('company_users')
                    ->where('users_id', $authUser->id)
                    ->pluck('company_id');

                if ($companyIds->isEmpty()) {
                    return response()->json(['status' => 'success', 'data' => []]);
                }

                $accessibleDeps = DB::table('department')
                    ->whereIn('company_id', $companyIds)
                    ->pluck('id');

                if ($accessibleDeps->isEmpty()) {
                    return response()->json(['status' => 'success', 'data' => []]);
                }

                $usersQuery->whereIn('users.department_id', $accessibleDeps);

            } elseif (in_array($authUser->user_types_id, [3, 4])) {
                // Branch Admin or Department Admin: departments assigned to the user
                $accessibleDeps = DB::table('department_users')
                    ->where('users_id', $authUser->id)
                    ->pluck('department_id');

                if ($accessibleDeps->isEmpty()) {
                    return response()->json(['status' => 'success', 'data' => []]);
                }

                $usersQuery->whereIn('users.department_id', $accessibleDeps);
            }
            // Super Admin (user_types_id == 1) sees all users (no filter)
        }

        $users = $usersQuery->get();

        if ($users->isEmpty()) {
            return response()->json(['status' => 'success', 'data' => []]);
        }

        // Get logs for these users in date range
        $logs = DB::table('users_logs')
            ->whereBetween('checkindate', [$startDate->toDateString(), $endDate->toDateString()])
            ->whereIn('username', $users->pluck('username'))
            ->get()
            ->groupBy('username');

        $report = [];

        for ($date = $startDate->copy(); $date->lte($endDate); $date->addDay()) {
            $dateStr = $date->toDateString();
            $dayName = $date->format('l'); // Day name

            foreach ($users as $user) {
                $logForDay = isset($logs[$user->username])
                    ? $logs[$user->username]->firstWhere('checkindate', $dateStr)
                    : null;

                if ($logForDay) {
                    $timeIn = $logForDay->timein;
                    $timeOut = $logForDay->timeout;

                    if ($timeIn && $timeOut) {
                        $startTimestamp = strtotime($timeIn);
                        $endTimestamp = strtotime($timeOut);
                        $diffInSeconds = $endTimestamp - $startTimestamp;

                        if ($diffInSeconds < 0) {
                            $workingHours = "00:00:00";
                        } else {
                            $hours = floor($diffInSeconds / 3600);
                            $minutes = floor(($diffInSeconds % 3600) / 60);
                            $seconds = $diffInSeconds % 60;
                            $workingHours = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
                        }
                    } else {
                        $workingHours = "Incomplete";
                    }
                    $status = 'Present';
                } else {
                    $timeIn = null;
                    $timeOut = null;
                    $workingHours = "00:00:00";
                    $status = 'Absent';
                }

                $report[] = [
                    'name' => $user->username,
                    'department' => $user->department_name,
                    'date' => $dateStr,
                    'day' => $dayName,
                    'status' => $status,
                    'time_in' => $timeIn ? date('H:i:s', strtotime($timeIn)) : null,
                    'time_out' => $timeOut ? date('H:i:s', strtotime($timeOut)) : null,
                    'working_hours' => $workingHours,
                ];
            }
        }

        // Prepare CSV headers for download
        $filename = 'attendance_report_' . now()->format('Ymd_His') . '.csv';

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];

        $callback = function () use ($report) {
            $file = fopen('php://output', 'w');

            // CSV column headers
            fputcsv($file, ['Name', 'Department', 'Date', 'Day', 'Status', 'Time In', 'Time Out', 'Working Hours']);

            // Data rows
            foreach ($report as $row) {
                fputcsv($file, [
                    $row['name'],
                    $row['department'],
                    $row['date'],
                    $row['day'],
                    $row['status'],
                    $row['time_in'],
                    $row['time_out'],
                    $row['working_hours'],
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);

    } catch (\Exception $e) {
        \Log::error('AttendanceReportController exportAttendanceCsv error: ' . $e->getMessage());
        return response()->json([
            'status' => 'error',
            'message' => 'Something went wrong: ' . $e->getMessage(),
        ], 500);
    }
}
}
    
    